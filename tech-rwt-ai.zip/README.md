# TECH RWT AI
1. रोज़ `data/batches/` में एक नई फ़ाइल `batch-N.json` (सिर्फ़ 1 लेख) upload करें।
2. बाकी सब अपने आप: GitHub Actions index, manifest, लेख का पेज, sitemap और robots.txt बना देता है।
3. डोमेन बदलना हो तो सिर्फ़ `scripts/config.js` में `SITE_URL` बदलें (Actions में "Run workflow" दबाएँ)।
4. GitHub Pages: Settings → Pages → Branch `main` / root चुनें; Settings → Actions → Workflow permissions में "Read and write" रखें।
5. कंप्यूटर पर जाँच: `node scripts/generate-index.js` (Node 18+, कोई पैकेज नहीं चाहिए)।
